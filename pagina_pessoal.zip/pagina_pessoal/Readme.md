
# Perfil Pessoal (HTML/CSS)
Projeto criado para aula de Desenvolvimento de Sites  Análise e Desenvolvimento de Sistemas - UniSENAI Blumenau.

Descrição do projeto:
Criar 2 páginas simples com HTML e CSS para uma página pessoal.

# Página 1
Descrição com fotos e detalhes sobre si.

# Página 2
Descrição e detalhes sobre seus hobbies preferidos.